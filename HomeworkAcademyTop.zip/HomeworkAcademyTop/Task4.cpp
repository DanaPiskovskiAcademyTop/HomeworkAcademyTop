#include <iostream>
using namespace std;

int main() {
	double R0;
	int R1 = 2;
	int R2 = 4;
	int R3 = 8;
	R0 = 1 / (double)R1 + 1 / (double)R2 + 1 / (double)R3;
	cout << 1 / R0;

}