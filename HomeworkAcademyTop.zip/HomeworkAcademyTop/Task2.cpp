#include <iostream>
using namespace std;

int main() {
	cout << "Every hunter wants..." << "\n"
		<< "\tRed" << "\n"
		<< "\t\ttBlue" << "\n"
		<< "\t\t\tBlack" << "\n"
		<< "\t\t\t\tYellow" << "\n"
		<< "\t\t\tWhite" << "\n"
		<< "\t\tViolet" << "\n"
		<< "\tPlun" << "\n"
		<< "\t\t\t\t\t\t\t\tHot Pink";

}
